package org.hyperledger.ariesframework.proofs

import okhttp3.OkHttpClient
import okhttp3.Request
import org.hyperledger.ariesframework.util.Base58
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

/**
 * 12id fork change (F12): a revocation registry's tails file, fetched and checked before use.
 *
 * Upstream read it with `URL.readBytes()`: no ISRG fallback (F8, so Android 7.0 could not fetch it from a Let's
 * Encrypt host), no retry on 429 (F10), no size limit, and no check against the registry's `tailsHash`. anoncreds
 * does not check the file either: a corrupted one makes every proof fail at the verifier ("Invalid proof",
 * implement/33 R0). Now:
 *   - it is fetched with the framework's client (`AgentHttpClient`);
 *   - it is refused over [MAX_TAILS_BYTES] (a registry of 100,000 is 24.4 MiB);
 *   - the base58 SHA-256 of what was read must equal `tailsHash`;
 *   - it is written to a temporary file and renamed, so a broken download never sits in the cache;
 *   - a cached file that does not match is deleted and fetched again.
 */
internal object TailsFile {
    const val MAX_TAILS_BYTES: Long = 50L * 1024 * 1024

    class TailsFileException(message: String) : IOException(message)

    /** The checked file at [target], downloading it from [location] (an http(s) URL or a local path) when needed. */
    fun fetch(client: OkHttpClient, location: String, tailsHash: String, target: File, maxBytes: Long = MAX_TAILS_BYTES): File {
        if (target.exists()) {
            if (hashOf(target) == tailsHash) return target
            target.delete()
        }
        target.parentFile?.mkdirs()
        val partial = File(target.parentFile, "${target.name}.part")
        try {
            val digest = if (location.startsWith("http://") || location.startsWith("https://")) {
                download(client, location, partial, maxBytes)
            } else {
                File(location).inputStream().use { copy(it, partial, maxBytes) }
            }
            val actual = Base58.encode(digest)
            if (actual != tailsHash) throw TailsFileException("tails file from $location does not match its hash (expected $tailsHash, got $actual)")
            if (!partial.renameTo(target)) throw TailsFileException("could not move the tails file into place at $target")
            return target
        } finally {
            partial.delete()
        }
    }

    private fun download(client: OkHttpClient, url: String, into: File, maxBytes: Long): ByteArray {
        client.newCall(Request.Builder().url(url).get().build()).execute().use { response ->
            if (!response.isSuccessful) throw TailsFileException("tails file download from $url failed with HTTP ${response.code}")
            val body = response.body ?: throw TailsFileException("tails file download from $url returned no body")
            val declared = body.contentLength()
            if (declared > maxBytes) throw TailsFileException("tails file at $url is $declared bytes, over the $maxBytes limit")
            return body.byteStream().use { copy(it, into, maxBytes) }
        }
    }

    /** Copies at most [maxBytes] into [into] and returns the SHA-256 of what was copied. */
    private fun copy(input: InputStream, into: File, maxBytes: Long): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val buffer = ByteArray(64 * 1024)
        into.outputStream().use { output ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > maxBytes) throw TailsFileException("tails file is over the $maxBytes byte limit")
                digest.update(buffer, 0, read)
                output.write(buffer, 0, read)
            }
        }
        return digest.digest()
    }

    private fun hashOf(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        file.inputStream().use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return Base58.encode(digest.digest())
    }
}
