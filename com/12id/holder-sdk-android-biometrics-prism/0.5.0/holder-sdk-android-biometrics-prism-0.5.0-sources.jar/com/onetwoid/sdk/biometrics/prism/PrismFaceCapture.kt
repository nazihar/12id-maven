package com.onetwoid.sdk.biometrics.prism

import android.content.Intent
import androidx.activity.ComponentActivity
import com.prismid.sdk.PrismIdResult
import com.onetwoid.sdk.BiometricCapture
import com.onetwoid.sdk.CaptureOutput
import com.onetwoid.sdk.CaptureSession
import com.onetwoid.sdk.OneTwoIdException
import kotlinx.coroutines.CompletableDeferred
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Prism face verification capture for the platform's `prism` provider.
 *
 * Register it once next to `OneTwoId.initialize`:
 * ```
 * OneTwoId.registerCapture(PrismFaceCapture())
 * ```
 * The platform opens the Prism session with the organisation's reference photo and hands this add-on
 * only the session token and Prism's address. The scan goes straight to Prism; the platform then reads
 * the result from Prism itself, so this returns nothing and what Prism's SDK reports on the phone is
 * not used.
 */
public class PrismFaceCapture : BiometricCapture {
    override val provider: String = "prism"
    override val version: Int = 1

    override suspend fun capture(activity: ComponentActivity, session: CaptureSession): CaptureOutput {
        val request = PrismRequest.parse(session.clientConfigJson)
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        // Kept in memory: our own intent carries only this id, never the session token.
        pending[id] = Pending(request, done)
        try {
            activity.startActivity(Intent(activity, PrismCaptureActivity::class.java).putExtra(PrismCaptureActivity.EXTRA_REQUEST, id))
            done.await()
        } finally {
            pending.remove(id)
        }
        return CaptureOutput("{}")
    }

    internal class Pending(val request: PrismRequest, val done: CompletableDeferred<Unit>)

    internal companion object {
        val pending = ConcurrentHashMap<String, Pending>()
    }
}

/** The platform's `clientConfig` for prism (see biometric-service providers/prism.ts). */
internal class PrismRequest(
    val baseUrl: String,
    val sessionToken: String,
    /** `en` or `bn`; anything else shows Prism's English screens. */
    val locale: String?,
) {
    // Never print the token.
    override fun toString(): String = "PrismRequest(baseUrl=$baseUrl, locale=$locale)"

    companion object {
        fun parse(json: String): PrismRequest = try {
            val root = JSONObject(json)
            val baseUrl = root.getString("baseUrl")
            val token = root.getString("sessionToken")
            require(baseUrl.startsWith("https://") || baseUrl.startsWith("http://")) { "baseUrl is not a URL" }
            require(token.isNotBlank()) { "empty session token" }
            PrismRequest(baseUrl, token, root.optString("locale").ifBlank { null })
        } catch (e: Exception) {
            throw OneTwoIdException.Internal("unexpected prism session configuration", e)
        }
    }
}

/**
 * What a finished Prism scan means for [PrismFaceCapture.capture]: null to return (the platform reads
 * the verdict from Prism), or the exception to throw. A pass and a failed scan look the same here on
 * purpose: the phone's account of the result is never the decision.
 */
internal object PrismOutcome {
    fun of(result: PrismIdResult): OneTwoIdException? = when (result) {
        is PrismIdResult.Success, is PrismIdResult.LivenessFailed -> null
        is PrismIdResult.Cancelled -> OneTwoIdException.BiometricCancelled()
        is PrismIdResult.Error -> OneTwoIdException.Internal("face scan failed: ${result.message}")
        // Only Prism's `full` mode asks for a document; the platform opens `reference_match` sessions.
        is PrismIdResult.NeedsIdUpload -> OneTwoIdException.Internal("unexpected Prism result: a document step in a reference_match session")
    }
}
