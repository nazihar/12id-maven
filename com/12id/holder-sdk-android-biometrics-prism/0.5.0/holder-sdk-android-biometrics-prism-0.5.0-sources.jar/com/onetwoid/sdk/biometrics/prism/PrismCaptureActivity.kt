package com.onetwoid.sdk.biometrics.prism

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.prismid.sdk.PrismIdSDK
import com.prismid.sdk.PrismIdSession
import com.onetwoid.sdk.OneTwoIdException

/**
 * A screenless trampoline for one [PrismFaceCapture.capture] call: asks for the camera (Prism's SDK
 * needs it granted before launch), starts Prism's scan with the session token, and completes the
 * caller's deferred with the outcome. Not exported.
 */
internal class PrismCaptureActivity : ComponentActivity() {
    private var pending: PrismFaceCapture.Pending? = null
    /** Set once Prism's scan was launched, so a recreated activity waits for its result instead of launching again. */
    private var launched = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchScan() else fail(OneTwoIdException.BiometricCancelled())
    }

    private val scan = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val error = PrismOutcome.of(PrismIdSDK.parseResult(result.resultCode, result.data))
        if (error == null) complete() else fail(error)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pending = intent.getStringExtra(EXTRA_REQUEST)?.let { PrismFaceCapture.pending[it] }
        if (pending == null) {
            // Recreated after process death: the capture that started us is gone.
            finish()
            return
        }
        launched = savedInstanceState?.getBoolean(STATE_LAUNCHED) ?: false
        if (launched) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchScan()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_LAUNCHED, launched)
    }

    private fun launchScan() {
        val request = pending!!.request
        launched = true
        // Prism's own intent carries the session token to Prism's activity, inside this app's process.
        // The token opens this one scan only and expires with the session (30 minutes).
        scan.launch(PrismIdSDK.createIntent(this, PrismIdSession(request.sessionToken, request.baseUrl, request.locale ?: "en", false)))
    }

    private fun complete() {
        pending?.done?.complete(Unit)
        finish()
    }

    private fun fail(error: OneTwoIdException) {
        pending?.done?.completeExceptionally(error)
        finish()
    }

    override fun onDestroy() {
        // Leaving without a result (e.g. the task was removed) counts as a cancel.
        if (isFinishing) pending?.done?.let { if (!it.isCompleted) it.completeExceptionally(OneTwoIdException.BiometricCancelled()) }
        super.onDestroy()
    }

    internal companion object {
        const val EXTRA_REQUEST = "com.onetwoid.sdk.biometrics.prism.REQUEST"
        private const val STATE_LAUNCHED = "launched"
    }
}
